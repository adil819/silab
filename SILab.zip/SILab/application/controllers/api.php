<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Api extends CI_Controller {
 public function index()
 {
//      //SENGAJA DI KOMEN BIAR KALAU GAK SENGJA DIAKSES JADI GAK EROR, WALAUPUN DB GK NGARUH
//   $url = file_get_contents("http://localhost/silab/api/ti17.json");
//   $json = json_decode($url,true);
//   $k =  0;
//   foreach ($json as $user) {
//       $data['nim'] = $user['NIM'];
//       $data['nama'] = $user['NAMA'];
//       $data['angkatan'] = 2017;
//       $data['kode_prodi'] = "1402";
//       $this->load->model('dosen/user_model');
//       $this->user_model->create_general('mahasiswa', $data);
//   }
  
 }
}

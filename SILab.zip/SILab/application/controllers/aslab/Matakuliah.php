<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Matakuliah extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
  {   parent::__construct();

  	// if ($this->session->userdata('login') == 0 || $this->session->userdata('user_level') != '1') redirect('auth/logout');

	$this->session->set_userdata('menu','matakuliah');

	$this->load->model('aslab/matakuliah_model', 'dbObject');
  }

 	public $tbl = 'nilai';
	public $id_name = 'nim';

	public function index()
	{
		//READ mahasiswa yang memiliki kom yg sama dengan yg ada di table kelas
		//$kom = "A22017";
		$i = 0;
		$temp = $this->session->userdata('user_id');
		$id_aslab = $this->dbObject->get_id_aslab($temp);
		$data['aslab'] = $this->dbObject->get_mahasiswaA($id_aslab[0]->nim);
		// print_r($data['aslab']);die;

		$this->load->model('aslab/kehadiran_model');
		$data['mhs'] = $this->kehadiran_model->get_kelasku($id_aslab[0]->id_aslab);
		foreach ($data['mhs'] as $key) {
			// print_r($key->kom);die;
			// echo '<br/>';
			$data['praktikan'][$i++] = $this->dbObject->get_praktikanku($key->kom);
		}
		//print_r($data['praktikan'][0][0]);die;

		$data['jenis'] = $this->dbObject->get_jenis_penilaian($data['mhs'][0]->id_kelas);		
		$j = 0;
		foreach ($data['jenis'] as $key) {
			foreach ($data['praktikan'] as $rows): 
				foreach ($rows as $row): 
					$data['nilai'][$key->jenis_penilaian][$row->nim] = $this->dbObject->get_nilai($data['mhs'][0]->id_kelas, $key->jenis_penilaian, $row->nim);	
				endforeach;
			endforeach;
		}			
		
		// print_r($data['nilai']['Kuis']['171402001'][0]->nilai);
		// echo '<br/>';
		// echo '<br/>';
		// echo '<br/>';
		// print_r($data['jenis']);
		// die;
		  //var_dump($data['mahasiswa']);die;
		$this->load->view('aslab/templates/header');
		$this->load->view('aslab/templates/sidebar',$data);
		$this->load->view('aslab/matakuliah/index',$data);
		$this->load->view('aslab/templates/modal');
		$this->load->view('aslab/templates/footer');
	}

	public function insert_jenis_penilaian() {   	
		$i=0;
		$temp = $this->session->userdata('user_id');
		$id_aslab = $this->dbObject->get_id_aslab($temp);
		$data['aslab'] = $this->dbObject->get_mahasiswaA($id_aslab[0]->nim);	
		$this->load->model('aslab/kehadiran_model');
		$data['mhs'] = $this->kehadiran_model->get_kelasku($id_aslab[0]->id_aslab);

		$data2 = $_POST;
		foreach ($data['mhs'] as $key) {
			// echo '<br/>';
			$data['praktikan'][$i++] = $this->dbObject->get_praktikanku($key->kom);
		}
		$this->load->model('aslab/Silabus_model');
		$this->Silabus_model->create_general('persentase_penilaian', $data2);
		$data3['jenis_penilaian'] = $data2['jenis_penilaian'];
		$data3['id_kelas'] = $data2['id_kelas'];
		$data3['nilai'] = 0;	

		foreach ($data['praktikan'] as $rows): 
			foreach ($rows as $row): 
				$data3['nim'] = $row->nim;
				$this->Silabus_model->create_general('nilai', $data3);
			endforeach;
		endforeach;	

	 	redirect(base_url()."index.php/aslab/matakuliah");  
	}

	public function update_nilai($id_kelas) {   	
		// print_r($_POST);die;
		$data2 = $_POST;

		$i = 0;
		$temp = $this->session->userdata('user_id');
		$id_aslab = $this->dbObject->get_id_aslab($temp);
		$data['aslab'] = $this->dbObject->get_mahasiswaA($id_aslab[0]->nim);
		// print_r($data['aslab']);die;

		$this->load->model('aslab/kehadiran_model');
		$data['mhs'] = $this->kehadiran_model->get_kelasku($id_aslab[0]->id_aslab);
		foreach ($data['mhs'] as $key) {
			// print_r($key->kom);die;
			// echo '<br/>';
			$data['praktikan'][$i++] = $this->dbObject->get_praktikanku($key->kom);
		}
		//print_r($data['praktikan'][0][0]);die;

		$data['jenis'] = $this->dbObject->get_jenis_penilaian($data['mhs'][0]->id_kelas);		
		$j = 0;
		foreach ($data['jenis'] as $key) {
			foreach ($data['praktikan'] as $rows): 
				foreach ($rows as $row): 
					$this->dbObject->update_nilai($id_kelas, $key->jenis_penilaian, $row->nim, $data2['nilai'][$key->jenis_penilaian][$row->nim]);	
				endforeach;
			endforeach;
		}	

	 	redirect(base_url()."index.php/aslab/matakuliah");  
	}

	public function update($param2='', $param1='')
	{
		$data['mhs'] = $this->dbObject->get_mahasiswa1($param2);
		//var_dump($data['mhs']);die;

		$this->load->view('aslab/templates/header');
		$this->load->view('aslab/templates/sidebar');
		$this->load->view('aslab/matakuliah/update', $data);
		$this->load->view('aslab/templates/footer');

		if ($param2 == 'do_update') 
		{
			$nilai = $this->input->post('nilai');
		
	        $data = array(
	       		'nilai' => $nilai
			);
	        
			if($this->dbObject->update_general($this->tbl, $this->id_name, $param1, $data)===TRUE)		// using direct parameter
			{
				$this->session->set_flashdata('pesan', [
               	        'title' => '',
               	        'message' => 'Data Berhasil Diubah',
               	        'type' => 'success'
               	        ]);
				?>
				<script>
					//alert(" Data berhasil diubah. ");
					location.replace("<?=base_url()?>index.php/aslab/matakuliah/");
				</script>
				<?php
				//redirect('master/jabatan','refresh');
			}
			else {
				$this->session->set_flashdata('pesan', [
               	        'title' => '',
               	        'message' => 'Data Gagal Diubah',
               	        'type' => 'danger'
               	        ]);
				?>
				<script>
					//alert(" Data gagal diubah. ");
					location.replace("<?=base_url()?>index.php/aslab/matakuliah/");
				</script>
				<?php
				//redirect('master/jabatan_insert','refresh');
			}
		}
	}

	public function printdata($param1)
	{
		$data['nilai']=$this->dbObject->get_mahasiswa1($param1);
		$this->load->view('aslab/matakuliah/print',$data);
	}



}

<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class kehadiran extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function __construct()
  {   parent::__construct();

  	// if ($this->session->userdata('login') == 0 || $this->session->userdata('user_level') != '1') redirect('auth/logout');

	$this->session->set_userdata('menu','kehadiran');

	$this->load->model('aslab/kehadiran_model', 'dbObject');
  }

 	public $tbl = 'nilai';
	public $id_name = 'nim';

	public function index()
	{
		$this->load->model('aslab/Matakuliah_model');
		$temp = $this->session->userdata('user_id');
		$id_aslab = $this->Matakuliah_model->get_id_aslab($temp);
		$data['aslab'] = $this->Matakuliah_model->get_mahasiswaA($id_aslab[0]->nim);
		//READ mahasiswa yang memiliki kom yg sama dengan yg ada di table kelas
		//$kom = "A22017";
		$i = 0;
		
		$data['mhs'] = $this->dbObject->get_kelasku($id_aslab[0]->id_aslab);
		$data['pertemuan_ke'] = $this->dbObject->get_last_pertemuan($data['mhs'][0]->id_kelas);
		foreach ($data['mhs'] as $key) {
			// print_r($key->kom);
			// echo '<br/>';
			$data['praktikan'][$i++] = $this->dbObject->get_praktikanku($key->kom);
		}
		
		// print_r($data['mhs']);
		// echo '<br/>';	
		// print_r($data['praktikan']);
		// die;

		$this->load->view('aslab/templates/header');
		$this->load->view('aslab/templates/sidebar',$data);
		$this->load->view('aslab/kehadiran/index',$data);
		$this->load->view('aslab/templates/modal');
		$this->load->view('aslab/templates/footer');
	}

	public function insert() {   
		
		$data['pertemuan_ke'] = $_POST['pertemuan_ke'];
		$data['id_kelas'] = $_POST['id_kelas'];
		$this->load->model('dosen/user_model');
		$i = 0;
		$data['nim'] = '0';	//mewakili semua yg hadir
		$data['status'] = 'hadir';
		$this->user_model->create_general('presensi_mahasiswa', $data);
		foreach ($_POST['nim'] as $key) {
			$data['nim'] = $_POST['nim'][$i];
			$data['status'] = $_POST['status'][$i++];
			if($data['status'] != 'hadir'){
			  $this->user_model->create_general('presensi_mahasiswa', $data);
			}
		}		

	 	redirect(base_url()."index.php/aslab/silabus/");  
	}

	public function update($param2='', $param1='')
	{
		$data['mhs'] = $this->dbObject->get_mahasiswa1($param2);
		//var_dump($data['mhs']);die;

		$this->load->view('aslab/templates/header');
		$this->load->view('aslab/templates/sidebar');
		$this->load->view('aslab/kehadiran/update', $data);
		$this->load->view('aslab/templates/footer');

		if ($param2 == 'do_update') 
		{
			$nilai = $this->input->post('nilai');
		
	        $data = array(
	       		'nilai' => $nilai
			);
	        
			if($this->dbObject->update_general($this->tbl, $this->id_name, $param1, $data)===TRUE)		// using direct parameter
			{
				$this->session->set_flashdata('pesan', [
               	        'title' => '',
               	        'message' => 'Data Berhasil Diubah',
               	        'type' => 'success'
               	        ]);
				?>
				<script>
					//alert(" Data berhasil diubah. ");
					location.replace("<?=base_url()?>index.php/aslab/kehadiran/");
				</script>
				<?php
				//redirect('master/jabatan','refresh');
			}
			else {
				$this->session->set_flashdata('pesan', [
               	        'title' => '',
               	        'message' => 'Data Gagal Diubah',
               	        'type' => 'danger'
               	        ]);
				?>
				<script>
					//alert(" Data gagal diubah. ");
					location.replace("<?=base_url()?>index.php/aslab/kehadiran/");
				</script>
				<?php
				//redirect('master/jabatan_insert','refresh');
			}
		}
	}

	public function printdata($id_aslab)
	{
		//READ mahasiswa yang memiliki kom yg sama dengan yg ada di table kelas
		//$kom = "A22017";
		$i = 0;
		$data['mhs'] = $this->dbObject->get_kelasku($id_aslab);
		foreach ($data['mhs'] as $key) {
			// print_r($key->kom);
			// echo '<br/>';
			$data['praktikan'][$i++] = $this->dbObject->get_praktikanku($key->kom);
		}
		$data['aslab'] = $this->dbObject->get_mahasiswa1($data['mhs'][0]->nim);
		$data['matkul'] = $this->dbObject->get_matkul($data['mhs'][0]->kode_matkul);
		
		$this->load->view('aslab/kehadiran/print',$data);
	}



}

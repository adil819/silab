<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Authh extends CI_Controller {

	public function index() {
		$this->load->view('login');
	}

	public function cek_login() {
		$data = array('user_name' => $this->input->post('user_name', TRUE),
			'user_password' => $this->input->post('user_password', TRUE)
		);
		$this->load->model('model_user'); // load model_user
		$hasil = $this->model_user->cek_user($data);
		if ($hasil->num_rows() == 1) {
			foreach ($hasil->result() as $sess) {
				$sess_data['logged_in'] = 'Sudah Loggin';
				$sess_data['user_id'] = $sess->user_id;
				$sess_data['user_name'] = $sess->user_name;
				$sess_data['user_level'] = $sess->user_level;
				$this->session->set_userdata($sess_data);
			}
			if ($this->session->userdata('user_level')=='admin') {
				
				$this->session->set_flashdata('pesan', [
               	        'title' => 'Login Sukses',
               	        'message' => 'Selamat Datang Di SiLab',
               	        'type' => 'success'
               	        ]);
				redirect('admin/kelas');
			}
			else if ($this->session->userdata('user_level')=='aslab') {

				$this->session->set_flashdata('pesan', [
               	        'title' => 'Login Sukses',
               	        'message' => 'Selamat Datang Di SiLab',
               	        'type' => 'success'
               	        ]);
				redirect('aslab/matakuliah');
			}		
			else if ($this->session->userdata('user_level')=='kepala lab') {
				$this->session->set_flashdata('pesan', [
               	        'title' => 'Login Sukses',
               	        'message' => 'Selamat Datang Di SiLab',
               	        'type' => 'success'
               	        ]);

				redirect('kepala_lab/inventaris');
			}		
			else { 
				$this->session->set_flashdata('pesan', [
               	        'title' => 'Login Sukses',
               	        'message' => 'Selamat Datang Di SiLab',
               	        'type' => 'success'
               	        ]);
				redirect('dosen/aslab');
			}
		}
		else {
			echo "<script>alert('Gagal login: Cek username, password!');history.go(-1);</script>";
		}
	}

}

?>

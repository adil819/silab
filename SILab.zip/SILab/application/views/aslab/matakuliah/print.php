
<!DOCTYPE html>
<html>
<head>
	<title>Laporan Nilai Mahasiswa</title>
<script type="text/javascript">
	window.onload = function() { window.print(); }
</script>
</head>
<body>
<?php foreach ($nilai as $key) {?>
	<center><b>Laporan Nilai Mahasiswa</b></center>
		<center>Fakultas Ilmu Komputer Dan Teknologi Informasi</center>
		<center>Universitas Sumatera Utara</center>
	<hr>

	<br>
	<b>Nama Mahasiswa : <?=$key->nama?></b>
	<br>
	<br>
	<b>NIM : <?=$key->nim?></b>
	<br>
	<br>
	<b>Angkatan : <?=$key->angkatan?></b>
	<br>
	<br> 
	<b>Mata Kuliah :</b>
	<br>
	<br>
	<b>Nilai : <?=$key->nilai?></b>
<?php } ?>
	</section>
	<br>
	<br>
	<br>
	<br>
</body>
</html>

<div class="content">
  <div class="row">
   <div class="col-md-12">
      <div class="card">
      <form class="form-horizontal" action="<?=base_url()?>index.php/aslab/kehadiran/insert" method="post">
                        <input type="number" class="form-control" name="pertemuan_ke" value="<?= $pertemuan_ke[0]['pertemuan_ke']+1?>" required="" hidden>
                        <input type="number" class="form-control" name="id_kelas" value="<?= $mhs[0]->id_kelas ?>" required="" hidden>
        <div class="card-header">
          <h4 class="card-title"> Kehadiran Praktikan Pekan Ini <strong>(Pertemuan Ke - <?= $pertemuan_ke[0]['pertemuan_ke']+1?>)</strong></h4>
        </div>
        <div class="card-body">

          <div class="toolbar">
            <button type="submit" class="btn btn-warning"><i class="fa fa-plus"></i> &nbsp; Kumpul Absensi Digital</button></a>
          </div>
          <div class="table-responsive-sm">
            <table id="datatable" class="table table-bordered" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th width="80">Nim</th>
                  <th width="300">Daftar Mahasiswa</th>
                  <th width="30">Sakit</th>
                  <th width="30">Izin</th>
                  <th width="30">Absen</th>
                  <th class="disabled-sorting text-right">Actions</th>
                </tr>
              </thead>
              <tbody>
              <?php $i = 0 ?>
                <?php $i=0; foreach ($praktikan as $rows): ?>
                <?php $i=0; foreach ($rows as $row): ?>
                  <tr>
                    <td class="text-center"><?=$row->nim?></td>
                    <td><?=$row->nama?></td>
                    <td>1</td>
                    <td>0</td>
                    <td>0</td>
                    <td class="text-right">
                        <input type="text" class="form-control" name="nim[<?=$i?>]" value="<?=$row->nim?>" required="" hidden>
                        <input type="radio" name="status[<?=$i?>]" value="hadir" checked> Hadir &nbsp;&nbsp;
                        <input type="radio" name="status[<?=$i?>]" value="sakit" > Sakit &nbsp;&nbsp;
                        <input type="radio" name="status[<?=$i?>]" value="izin" > Izin &nbsp;&nbsp;
                        <input type="radio" name="status[<?=$i++?>]" value="alpa "> Absen
                      </a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                  <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        </div>
                      </form>
      </div>
    </div>
  </div>
</div>

  <script type="text/javascript">
    $(document).ready(function() {
      $('#datatable').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [-1 , 25, 50],
          ["All", 10, 25, 50]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }

      });

      var table = $('#datatable').DataTable();

      // Edit record
      table.on('click', '.edit', function() {
        $tr = $(this).closest('tr');

        var data = table.row($tr).data();
        alert('You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.');
      });

      // Delete a record
      table.on('click', '.remove', function(e) {
        $tr = $(this).closest('tr');
        table.row($tr).remove().draw();
        e.preventDefault();
      });

      //Like record
      table.on('click', '.like', function() {
        alert('You clicked on Like button');
      });
    });
  </script>
  <script src="<?=base_url()?>assets/js/plugins/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

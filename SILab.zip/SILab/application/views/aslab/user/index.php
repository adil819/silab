      <div class="content">
        <div class="row">
        <div class="col-md-12">
            <div class="card">
              <div class="card-header">
                <h4 class="card-title"> Profile User </h4>
              </div>
              <div class="card-body">
              <h5>
                      <small>
                        <span style="margin-right: 20px"> <i class="nc-icon nc-single-02"></i></span>
                        <b><!-- <?=$this->session->userdata('user_nama');?> -->ARI</b>
                      </small>
                    </h5>
                 
                </div>
</div>
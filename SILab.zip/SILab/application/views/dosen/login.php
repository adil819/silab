<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Dosen</title>
</head>
<body>

<h1>Haii selamat datang dihalaman <b>dosen</b>, anda login sebagai <?php echo $user_name; ?></h1> <a href="<?php echo site_url('dosen/c_dosen/logout'); ?>">Logout</a>

</body>
</html>
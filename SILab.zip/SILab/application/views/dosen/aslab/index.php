<div class="content">
  <div class="row">
   <div class="col-md-12">
      <div class="card">
        <div class="card-header">
          <h4 class="card-title"> Asisten Laboratorium</h4>
        </div>
        <div class="card-body">

          <div class="toolbar">
          <?php foreach ($aslab as $key): ?>
           <span><h5><small><b>Nama Aslab : <?=$key->nama?></b></small></h5></span>
           <!--  <a href="#"><button class="btn btn-success"><i class="fa fa-plus"></i> &nbsp; Tambah Data Baru</button></a> --> 
          <?php ?>
          <!-- loop setiap pertemuan -->
          <?php 
          if(isset($pertemuan_ke[$key->id_aslab][0]['pertemuan_ke'])){
          for($j=1; $j<=$pertemuan_ke[$key->id_aslab][0]['pertemuan_ke']; $j++){ ?> 
          <span><b>Pertemuan Ke <?= $j ?> </b></span>
          <div class="table-responsive-sm">
            <table id="" class="table table-bordered" cellspacing="0" width="100%">
              <thead>
                <tr>
                  <th width="35">No</th>
                  <th class="disabled-sorting" width="200">NIM Mahasiswa</th>
                  <th class="disabled-sorting" width="400">Nama Mahasiswa</th>
                  <th class="disabled-sorting text-center">Status</th>
                </tr>
              </thead>
              <tbody>
              <?php $i=1; foreach ($absen[$key->id_aslab][0] as $row): 
                if($row->pertemuan_ke == $j){?> 
                <tr>
                  <td class="text-center"><?=$i?></td>
                  <td><?=$row->nim?></td>
                  <td><?=$row->nama?></td>
                  <td class="text-center">
                  <?php 
                  if ($row->status == 'hadir')
                     echo "<span class='badge badge-pill badge-success'>Hadir</span>";
                  else if ($row->status == 'alpa') 
                    echo "<span class='badge badge-pill badge-danger'>Alpa</span>";
                  else if ($row->status == 'sakit') 
                    echo "<span class='badge badge-pill badge-warning'>Sakit</span>";
                  else if ($row->status == 'izin') 
                    echo "<span class='badge badge-pill badge-warning'>Izin</span>";

                  ?>
                    <!-- <a href="<?php echo base_url();?>index.php/dosen/matakuliah/update/<?=$row->nim?>" class="btn btn-warning btn-link btn-icon">
                    <i class="fa fa-edit"></i>
                    </a> -->
                  </td>
                </tr>
              <?php }
               $i++; endforeach; ?> 
              </tbody>
            </table>
          </div>
          <br>
          <?php } }
          else{
            echo '<strong>&nbsp;&nbsp;&nbsp;&nbsp;Keterangan: Semua Praktikan Selalu Hadir</strong><br/><hr/><br/>';
          }?>
          <?php endforeach;  ?>

  <script type="text/javascript">
    $(document).ready(function() {
      $('#datatable').DataTable({
        "pagingType": "full_numbers",
        "lengthMenu": [
          [10, 25, 50, -1],
          [10, 25, 50, "All"]
        ],
        responsive: true,
        language: {
          search: "_INPUT_",
          searchPlaceholder: "Search records",
        }

      });

      var table = $('#datatable').DataTable();

      // Edit record
      table.on('click', '.edit', function() {
        $tr = $(this).closest('tr');

        var data = table.row($tr).data();
        alert('You press on Row: ' + data[0] + ' ' + data[1] + ' ' + data[2] + '\'s row.');
      });

      // Delete a record
      table.on('click', '.remove', function(e) {
        $tr = $(this).closest('tr');
        table.row($tr).remove().draw();
        e.preventDefault();
      });

      //Like record
      table.on('click', '.like', function() {
        alert('You clicked on Like button');
      });
    });
  </script>
  <script src="<?=base_url()?>assets/js/plugins/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>

	<section class="feature-area">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8">
				</div>
			</div>
			<div class="feature-inner row">
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
					<!-- 	<i class="ti-crown"></i> -->
						<center><h4>BPH</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
							<p>
								<center><button class="">Masuk</button></center>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-briefcase"></i> -->
						<center><h4>DOSEN</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".3s">
							<p>
							<a href="<?=base_url()?>index.php/home/fh">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>ASLAB</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
								<center><button>Masuk</button></center>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>LABORATORIUM FT</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
								<b>Teknik Elektro</b>
								<br>Dasar Konversi Energi
								<br>Sistem Pengaturan dan Komputer
								<br>Pengukuran Besaran Listrik
								<br>Distribusi
								<br>Teknik Tegangan Tinggi
								<br>Antena
								<br>Rangkaian Listrik
								<br>Dasar Telekomunikasi
								<br>Elektronika Dasar<br><br>

								<b>Teknik Industri</b>
								<br>Manufaktur
								<br>Studio Audio Visual
								<br>Pengukutan dan Statistik
								<br>Ergonomi dan Pengukuran Kerja
								<br>Sistem Produksi
								<br>Tata Letak Pabrik dan Pemindahan Bahan<br><br>

								<b>Teknik Arsitektur</b>
								<br>Lab Perancangan
								<br>Lab Perkotaan dan Permukiman
								<br>Teknologi Bangunan
								<br>Sejarah Teori dan Kritik Arsitektur<br><br>

								<b>Teknik Mesin</b>
								<br>Menggambar teknik
								<br>Tugas menggambar mesin
								<br>AutoCad 
								<br>Logam, proses produksi
								<br>fenomena dasar
								<br>praktikum prestasi mesin

							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
	<section class="feature-area">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8">
				</div>
			</div>
			<div class="feature-inner row">
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
					<!-- 	<i class="ti-crown"></i> -->
						<center><h4>Fakultas Kedokter </h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
							<p>
							<a href="<?=base_url()?>index.php/home/fk">
								<center><button class="">Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-briefcase"></i> -->
						<center><h4>Fakultas Ilmu Budaya</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".3s">
							<p>
							<a href="<?=base_url()?>index.php/home/fib">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>Fakultas Pertanian</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
							<a href="<?=base_url()?>index.php/home/fp">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
					<!-- 	<i class="ti-crown"></i> -->
						<center><h4>Fakultas Hukum </h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
							<p>
							<a href="<?=base_url()?>index.php/home/fh">
								<center><button class="">Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-briefcase"></i> -->
						<center><h4>Fakultas Teknik</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".3s">
							<p>
							<a href="<?=base_url()?>index.php/home/ft">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>Fakultas Ekonomi & Bisnis</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
							<a href="<?=base_url()?>index.php/home/feb">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
					<!-- 	<i class="ti-crown"></i> -->
						<center><h4>Fakultas Kedokteran Gigi </h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
							<p>
							<a href="<?=base_url()?>index.php/home/fkg">
								<center><button class="">Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-briefcase"></i> -->
						<center><h4>Fakultas Matematika dan Ilmu Pengetahuan Alam</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".3s">
							<p>
							<a href="<?=base_url()?>index.php/home/fmipa">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>Fakultas Ilmu Sosial dan Ilmu Politik</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
							<a href="<?=base_url()?>index.php/home/fisip">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>Fakultas Kesehatan Masyarakat</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
							<a href="<?=base_url()?>index.php/home/fkm">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
					<!-- 	<i class="ti-crown"></i> -->
						<center><h4>Fakultas Farmasi </h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
							<p>
							<a href="<?=base_url()?>index.php/home/farmasi">
								<center><button class="">Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-briefcase"></i> -->
						<center><h4>Fakultas Psikologi</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".3s">
							<p>
							<a href="<?=base_url()?>index.php/home/fpsi">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
					<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>Fakultas Keperawatan</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
							<a href="<?=base_url()?>index.php/home/fper">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
					<!-- 	<i class="ti-crown"></i> -->
						<center><h4>Fakultas Ilmu Komputer dan Teknologi Informasi </h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
							<p>
							<a href="<?=base_url()?>index.php/home/fasilkomti">
								<center><button class="">Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-briefcase"></i> -->
						<center><h4>Fakultas Kehutanan</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".3s">
							<p>
							<a href="<?=base_url()?>index.php/home/fhut">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
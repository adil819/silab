	<section class="faculty-area section-gap">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8">
					<div class="section-title text-center">
						<h1>Berita Dan Artikel</h1>
						<p>
							Ini Nanti Di Isi dengan Artikel Berita FKG
						</p>
					</div>
				</div>
			</div>
			<div class="row justify-content-center d-flex align-items-center">
			</div>
		</div>
	</section>
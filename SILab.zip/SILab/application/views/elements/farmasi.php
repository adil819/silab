	<section class="feature-area">
		<div class="container">
			<div class="row justify-content-center">
				<div class="col-lg-8">
				</div>
			</div>
			<div class="feature-inner row">
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
					<!-- 	<i class="ti-crown"></i> -->
						<center><h4>BPH</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".1s">
							<p>
								<center><button class="">Masuk</button></center>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-briefcase"></i> -->
						<center><h4>DOSEN</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".3s">
							<p>
							<a href="<?=base_url()?>index.php/home/fh">
								<center><button>Masuk</button></center>
							</a>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-4 col-md-6">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>ASLAB</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
								<center><button>Masuk</button></center>
							</p>
						</div>
					</div>
				</div>
				<div class="col-lg-12">
					<div class="feature-item">
						<!-- <i class="ti-medall-alt"></i> -->
						<center><h4>LABORATORIUM FARMASI</h4></center>
						<div class="wow fadeIn" data-wow-duration="1s" data-wow-delay=".5s">
							<p>
								<br>Farmasetika dasar 
								<br>Kimia farmasi kuantitatif
								<br>Kimia farmasi kualitatif
								<br>Kimia organik
								<br>Mikrobiologi farmasi
								<br>Botani farmasi
								<br>Biokimia farmasi
								<br>Statistika farmasi
								<br>Tablet
								<br>Teksed

							</p>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>
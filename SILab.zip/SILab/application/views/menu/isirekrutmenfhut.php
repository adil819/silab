
	<!-- Start Banner Area -->
		<?php include 'application/views/elements/banner.php'; ?>
	<!-- End Banner Area -->



	<!-- Start Courses Area -->
	<?php include 'application/views/elements/isifhut.php'; ?>
	<!-- End Courses Area -->


	<!-- Start Testimonials Area -->
	<!-- <?php include 'application/views/elements/testimonial.php'; ?> -->
	<!-- End Testimonials Area -->


	<!-- Start Footer Area -->
		<?php include 'application/views/elements/footer.php'; ?>
	<!-- End Footer Area -->

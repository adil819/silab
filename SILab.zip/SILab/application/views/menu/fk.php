	<!-- Start Banner Area -->
		<?php include 'application/views/elements/banner.php'; ?>
	<!-- End Banner Area -->


	<!-- Start About Area -->
	<!-- 	<?php include 'application/views/elements/area.php'; ?> -->
	<!-- End About Area -->


	<!-- Start Courses Area -->
<!-- 		<?php include 'application/views/elements/course.php'; ?> -->
	<!-- End Courses Area -->


	<!--Start Feature Area -->
		<?php include 'application/views/elements/fk.php'; ?>
	<!-- End Feature Area -->


	<!-- Start Faculty Area -->
		<?php include 'application/views/elements/fkartikel.php'; ?>
	<!-- End Faculty Area -->


	<!-- Start Testimonials Area -->
	<!-- 	<?php include 'application/views/elements/testimonial.php'; ?> -->
	<!-- End Testimonials Area -->


	<!-- Start Footer Area -->
		<?php include 'application/views/elements/footer.php'; ?>
	<!-- End Footer Area -->

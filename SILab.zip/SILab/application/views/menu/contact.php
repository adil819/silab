

	<!-- Start Banner Area -->
		<?php include 'application/views/elements/banner.php'; ?>
	<!-- End Banner Area -->

	<!-- Start contact-page Area -->
		<?php include 'application/views/elements/kontak.php'; ?>
	<!-- End contact-page Area -->

	<!-- Start Footer Area -->
		<?php include 'application/views/elements/footer.php'; ?>
	<!-- End Footer Area -->

	<!-- ####################### Start Scroll to Top Area ####################### -->

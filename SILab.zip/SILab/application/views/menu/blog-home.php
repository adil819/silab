

	<!-- Start Banner Area -->
		<?php include 'application/views/elements/banner.php'; ?>
	<!-- End Banner Area -->

	<!-- Start top-category-widget Area -->
		<?php include 'application/views/elements/category.php'; ?>
	<!-- End top-category-widget Area -->

	<!-- Start post-content Area -->
		<?php include 'application/views/elements/post.php'; ?>
	<!-- End post-content Area -->

	<!-- Start Footer Area -->
		<?php include 'application/views/elements/footer.php'; ?>
	<!-- End Footer Area -->

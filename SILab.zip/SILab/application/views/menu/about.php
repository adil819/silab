

	<!-- Start Banner Area -->
		<?php include 'application/views/elements/banner.php'; ?>
	<!-- End Banner Area -->


	<!-- Start About Area -->
		<?php include 'application/views/elements/area.php'; ?>
	<!-- End About Area -->


	<!-- Start Faculty Area -->
		<?php include 'application/views/elements/member.php'; ?>
	<!-- End Faculty Area -->


	<!-- Start Testimonials Area -->
		<?php include 'application/views/elements/testimonial.php'; ?>
	<!-- End Testimonials Area -->


	<!-- Start Footer Area -->
		<?php include 'application/views/elements/footer.php'; ?>
	<!-- End Footer Area -->

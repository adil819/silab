

	<!-- Start Banner Area -->
		<?php include 'application/views/elements/banner.php'; ?>
	<!-- End Banner Area -->

	<!-- Start Sample Area -->
		<?php include 'application/views/elements/sample.php'; ?>
	<!-- End Sample Area -->
	<!-- Start Button -->
		<?php include 'application/views/elements/button.php'; ?>
	<!-- End Button -->
	<!-- Start Align Area -->
			<?php include 'application/views/elements/align.php'; ?>
			<!-- End Align Area -->

			<!-- Start Footer Area -->
		<?php include 'application/views/elements/footer.php'; ?>

		<!-- End Footer Area -->
